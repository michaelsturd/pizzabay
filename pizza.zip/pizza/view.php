<?php
$pid = $_GET['pid'];
require 'auth_session.php';
require 'connect.php';
$sql = "SELECT * FROM post WHERE post_id = '$pid'";
$query = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($query);


$sel = "SELECT * FROM comments WHERE post_id = '$pid'";
$result = mysqli_query($conn, $sel);

?>
<!DOCTYPE html>
<html>
<head>
	<title>View comments and comment</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
	<div class="viewpost">
		<div class="notification"></div>
		<p id="demo"><a href="newsfeed.php?">Back to newsfeed</a></p>
	<div class="mainpost">
		<small><strong><?php echo $row['username'];?></strong></small>
	<p><?php echo $row['post_content'];?></p>		
	<input type="hidden" class="pid" value="<?php echo $row['post_id'];?>"  style="display: none;">
	<input type="hidden" class="comment_owner_username" value="<?php echo $_SESSION['username'];?>">
	<input type="hidden" class="pid" value="<?php echo $row['post_id'];?>"  style="display: none;">
	</div>
	
	<div class="commentthreads">
		<?php while ($threads = mysqli_fetch_assoc($result)) :?>

			<div>
				<strong style="text-transform: capitalize; margin-bottom: 10px;"><a href="#"><?php echo $threads['comment_owner_username'];?></a></strong>
			<p style="border-bottom: 1px solid black; height: auto;"><?php echo $threads['comments'];?></p>
			</div>
		<?php endwhile;?>
	</div>
	<div class="comment_text_box">
		<textarea class="message" placeholder="Write your comment.."></textarea>
		<input type="button" class="submit" id="submit" value="Send">
	</div>
	</div>

</body>

<script src="jquery.js"></script>
<script>
	$(document).ready(function() {
		$('#submit').click(function(){
			$('#submit').val('Please wait...');
			alert('hey');
		var message = $('.message').val();
		var pid = $('.pid').val();
		var comment_owner_username = $('.comment_owner_username').val();
		$.ajax({
			url:'save_comment.php',
			data:'message='+message+'&pid='+pid+'&comment_owner_username='+comment_owner_username,
			type:'post',
			success:function(response){
				console.log(response);
				$('.notification').html(response);
			}
		});
		});

		// if (view =='') {
		// 	$.ajax({
		// 		url:'list_comment.php',
		// 		success:function(resp);
		// 	})
		// }
		
	})
</script>
</html>