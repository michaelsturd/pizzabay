<?php
// require 'auth_session.php';
require 'connect.php';

$status = '';
$totalrow = '';

if (isset($_POST['sendpost'])) {
	$poster_username = $_SESSION['username'];
	$userpost = $_POST['userpost'];
	$userid = $_POST['userid'];
	$dateposted = date("Y");

	$sql = "INSERT INTO post(username, post_content, poster, dateposted) VALUES('$poster_username','$userpost','$userid','$dateposted')";

	$result = mysqli_query($conn, $sql);
	if ($result) {
		$status = "Your Post Has Been Sent.!";
	}
	else{
		$status = "Failed To Post Data";
	}
}





// $total='';
// UPDATE COMMENTS...
	// $con = "SELECT * FROM comments";
	// $saf = mysqli_query($conn, $con);
	// $countrow = mysqli_num_rows($saf);

	// echo $countrow;

if (isset($_POST['sendcomment'])) {
	$commentbar = $_POST['commentbar'];
	$comment_userid = $_POST['comment_userid'];
	$poster_id	= $_POST['poster_id'];
	$comment_username = $_POST['comment_username'];

	$sql = "INSERT INTO comments(comments,comment_username,comment_userid,user_id) VALUES('$commentbar','$comment_username','$comment_userid','$poster_id')";
	$rule = mysqli_query($conn, $sql);
	

	if ($rule) {

	echo"<script>alert('Comment sent')</script>";
	// echo $totalrow;
	


	
	}

	else{
		echo"<script>alert('Comment not sent')</script>";
	}
}

	
	

	// echo $totalrow;
		// COUNT COMMENTS

	// $sle = " SELECT comments.user_id, comments.";
	// $coun = "SELECT * FROM comments WHERE user_id = '$poster_id'";
	// $quer = mysqli_query($conn, $coun);
	// $tota = mysqli_num_rows($quer);
	// $totalrow = $tota;







?>