<?php
require 'function.php';
if (isset($_POST['register'])) {
	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	registration($fullname,$username,$email,$password);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Now</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	
	<style>
	
body{
	background-color: black;
}


	</style>



</head>
<body>
<div class="container">
	<div class="loginForm">
		<form method="post">
			<input type="text" name="fullname" placeholder="Fullname">
			<input type="text" name="username" placeholder="Username required">
			<input type="email" name="email" placeholder="Enter email">
			<input type="password" name="password" placeholder="Choose your password">
			<button type="submit" name="register" class="login">Submit</button>
			<a href="login.php" class="reg">Login</a>
		</form>
	</div>
</div>
</body>
</html>