<?php
require 'connect.php';

$message = $_POST['message'];

$pid = $_POST['pid'];
$comment_owner_username = $_POST['comment_owner_username'];
// echo $pid;
$quer = "INSERT INTO comments(comments,post_id,comment_owner_username) VALUES('".$message."','".$pid."','".$comment_owner_username."')";

$sql = mysqli_query($conn, $quer);
$repl='';
if ($sql) {

	$repl .= "<p>dpne</p>";
}

else{

	$repl .= "<p>error</p>";
}

?>