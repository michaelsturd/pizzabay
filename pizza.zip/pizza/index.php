<?php

if (isset($_POST['ordernow'])) {
	$pizzatypes = $_POST['pizzatypes'];
	$quantity = $_POST['quantity'];
	$contact = $_POST['contact'];

	$query =  "INSERT INTO orders() VALUES()";
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Hello Doc.</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
<div class="container">

	<div class="pizzablock">
		<div class="items">
			<div>
		<p>Go to our feeds section to check feeds about our services</p>
		<a href="dashboard.php">FeedBacks</a>
		<!-- <a href="register.php"></a> -->
		<hr>
	</div>
			<div class="displayimg">
			<img src="img/pizza.jfif">
		 	</div>
		</div>
		<div>
		<h3>Order Your Pizza</h3>
		<p id="demo"></p>
		<form method="POST">
			<label>Pizza Type</label>
			<br>
			<select id="items" name="pizzatypes">
				<option value="" selected=""></option>
				<option value="Suya Pizza" >Suya Pizza</option>
				<option value="Chicken Pizza" >Chicken Pizza</option>
				<option value="Beef Pizza" >Beef Pizza</option>
				<option value="Turkey Pizza" >Turkey Pizza</option>
			</select>
			<br>
			<label>Quatity</label><br>
			<input type="text" name="quantity" id="quant" >
			<br><br>
			<label>Phone number</label><br>
			<input type="text" name="contact" id="contact" placeholder="Enter contact number">
			<br><br>
			<label>Sum: <span id="sum"></span></label>
			<br>
			<button name="ordernow">Order Now</button>
		</form>
	</div>
	</div>
</div>
<script>
	var pizzaprice = 4000;
	//var select =  document.querySelector('#items');
	//var text = select.options[select.selectedIndex].text;
	var quantity = document.getElementById('quant').value;
	// document.getElementById('demo').innerHTML = quantity;
	console.log(quantity);
	console.log(pizzaprice);
	sum = pizzaprice;
	console.log(sum);

	// var sum = document.querySelector('#sum').value;
	// sum.value = pizzaprice * quantity;
	// console.log(sum);
</script>
</body>
</html>