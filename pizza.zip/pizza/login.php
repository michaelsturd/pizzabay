<?php
require 'function.php';

// require 'connect.php';
$error = 'User not found!';

if (isset($_POST['login'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];

	login($username,$password);


	// $insert = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
	// $result = mysqli_query($conn, $insert);

	// if ($result) {
	// 	header("location: dashboard.php?username=$username");
	// }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Now</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	
	<style>




body{
	background-color: black;
}


	</style>



</head>
<body>
<div class="container">
	<div class="loginForm">
		<form method="post">
			<input type="text" name="username" id="username" placeholder="Username" required="">
			<div id="error"></div>
			<input type="password" name="password" id="password" placeholder="Password" required="">
			<button type="submit" name="login" id="login" class="login">Login</button>
			<a href="register.php" class="reg">Register</a>
		</form>
	</div>
</div>
</body>
<script src="jquery.js"></script>
<script>
	// $(document).ready(function(){
	// 	$('#login').click(function(e){
	// 		e.preventDefault()
	// 		var username = $('#username').val();
	// 		var password = $('#password').val();

	// 		if ($('#username').val() == '' || $('#password').val() =='') {
	// 			$('#error').html('Please fill all fields completely');
	// 		}
	// 	})
	// })
</script>
</html>