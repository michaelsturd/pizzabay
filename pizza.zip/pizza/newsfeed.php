<?php
require 'auth_session.php';
require 'connect.php';
require 'actions.php';

$userid = $_SESSION['id'];
$comment_userid = $_SESSION['id'];
$comment_username = $_SESSION['username'];

;
?>
<!DOCTYPE html>
<html>
<head>
	<title>News feed</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>

	<div class="post_sections">
			<h3><?php echo $status;?></h3>
			<form method="post" id="postform">
				<textarea required="" cols="30" rows="3" name="userpost"  id="textareas" placeholder="Share Post..."></textarea>
				<input type="hidden" name="userid" value="<?php echo $userid;?>">
				<div id="error" style="color: red;"></div>
				<button name="sendpost" id="post" type="submit">Post</button>
			</form>

			<hr>
			<a href="logout.php">Logout</a><br>
			<a href="dashboard.php">Dashboard</a>
	</div>

		<!-- ======================================== -->




		<div class="wrapper">

			<?php 
			// SELECT ALL THE POST FROM DATABASE

$sqll = "SELECT * FROM post";
$runn = mysqli_query($conn, $sqll);
// $row = mysqli_fetch_assoc($runn);

while ($row = mysqli_fetch_assoc($runn))
 :?>
		<div class="post_card">
			<div class="postbody">
				<strong><a href="#"> <?php echo $row['username'];?>	</a></strong>
				<p>
					<?php echo $row['post_content'];?>	

				</p>
				<a href="view.php?pid=<?php echo $row['post_id'];?>">Comment</a>
				<span class="count_comment"><?php echo $totalrow;?></span>
			</div>
			
		</div>
		<?php endwhile;?>
	</div>


	</div>
</div>
</body>
<script src="jquery.js"></script>
<script>
	$(document).ready(function(){
		$('#replycomment').click(function(){
			$('#commentbar').show();
			$('#replycomment').hide();
		})

		// $('#postform').on('submit', function(event){
		// 	event.preventDefault();
		// 	if ($('#postform').val() =='') {
		// 		$('#error').text('Field required');

			// }
			// else{
			// 	$.ajax({
			// 		method:'post',
			// 		url:'function.php',
			// 		data:$('#postform'),
			// 		dataType:'json',
			// 		success:function(data){
			// 			console.log(data.notification);
			// 			alert('Posted');
			// 		}


			// 	});
				// sendpost($userpost);
			// }
		// })

	
	});
</script>
</html>