<?php
require 'connect.php';

require 'auth_session.php';


$setlimit = 1;

$user_id = $_GET['id'];

if (isset($_POST['pay'])) {
	$amount = $_POST['amount'];
	$order_id = rand(23,000);
	$id = $user_id;

	$sel = "SELECT * FROM users WHERE id = '$user_id'";
	$test = mysqli_query($conn, $sel);
	$row = mysqli_fetch_assoc($test);
	$limits = $row['limits'];
	
	if ($limits < $setlimit ) {
		// $setlimit = 1;
		echo "<script> alert('Limit is exhausted for this Transaction')</script>";
		
	}
	else {
	if ($limits == 2 ) {
		
		$sql = "INSERT INTO payment(amount, user_id, order_id) VALUES('$amount','$user_id','$order_id')";
		$run = mysqli_query($conn, $sql);


		$update = "UPDATE users SET limits = '$setlimit' WHERE id ='$user_id'";
		$try = mysqli_query($conn, $update);

		if ($run) {
		echo "<script>alert('Transaction Completed')</script>";
	}
	}

	else{
		if ($limits == 1) {
			$sql = "INSERT INTO payment(amount, user_id, order_id) VALUES('$amount','$user_id','$order_id')";
		$run = mysqli_query($conn, $sql);


		$update = "UPDATE users SET limits = 0 WHERE id ='$user_id'";
		$try = mysqli_query($conn, $update);
		}

			if ($run) {
		echo "<script>alert('Transaction Completed')</script>";
	}
	}

	
	
}
}

	// else{
	// 	echo "<script>alert('Transaction Not Completed')</script>";	
	// }
// }
// }

// echo $limits;
?>

<!DOCTYPE html>
<html>
<head>
	<title>Transfer funds</title>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
<div>
	<h4>Transfer Funds</h4>
	<hr>
	<form method="post">
			<input type="text" name="amount" placeholder="Amount">
			<button type="submit" name="pay" class="login">Transfer</button>
			<a href="dashboard.php" class="reg">Back</a>
		</form>
</div>
</body>
</html>