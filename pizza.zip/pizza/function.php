<?php

session_start();
 function login($username, $password){
	
	require 'connect.php';

	$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);


	if ( mysqli_num_rows($result) > 0) {
		
	$_SESSION['username'] = $row['username'];
	$_SESSION['id'] = $row['id'];
	$_SESSION['fullname'] = $row['fullname'];
	$_SESSION['email'] = $row['email'];
		header("location: dashboard.php?<?php echo ".$_SESSION['username'].";?>");
	}
	// else{

	// echo "error";
 //  }
}


function registration($fullname,$username,$email,$password){
	
	require 'connect.php';

	$insert = "INSERT INTO users(fullname,username,email,password) VALUES('$fullname','$username','$email','$password')";
	$result = mysqli_query($conn, $insert);

	if ($result) {
		echo"<script>alert('Done!!!')</script>
		";
	}
	else{

		echo"<script>alert('Failed!!!')</script>
		";
  }
}


	if (isset($_POST['post'])) {
		$userpost = $_POST['post'];

		$sql = "INSERT INTO post(post_content,poster,dateposted) VALUES('$userpost','$user_id','$dateposted')";
		$result = mysqli_query($conn, $sql);
		$output ='';

		if ($result) {
			$output.='
			<p>Post submitted</p>
			';
			$data = array('notification' => $output);
			echo json_encode($data);
		}
		
		else{
			$output.='
			<p>Failed</p>
			';
			$data = array('notification' => $output);
			echo json_encode($data);
		}
	}


?>