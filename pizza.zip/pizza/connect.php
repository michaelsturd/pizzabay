<?php
$server = 'localhost';
$user = 'root';
$pass = '';
$db = 'pizza';
$conn = mysqli_connect($server,$user,$pass,$db); //or die("fail to connect");

if ($conn != true) {
	echo"
		<script>alert('Not Connected')</script>
	";
}