<?php
require 'connect.php';
require 'auth_session.php';
$username = $_SESSION['username'] ;
$id = $_SESSION['id'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
<div class="wrapper">
	<h3>Hello <?php echo $username;?></h3>
	<a href="logout.php">Logout</a>
	<hr>
	<a href="payment.php?id=<?php echo $id;?>">Transfer Funds</a>
	<a href="newsfeed.php?id=<?php echo $id;?>">News Feeds</a>
</div>
</body>
</html>